#include "stm32f10x.h"                  
#include "Delay.h"
#include "OLED.h"

int main(void)
{
	Delay_ms(500);
	OLED_Init();
	OLED_Clear();

	OLED_ShowCN(0, 0, 0);   // ?
	OLED_ShowCN(16, 0, 1);  // ?
	OLED_ShowCN(32, 0, 2);  // ?
	OLED_ShowString(0, 2, "632407030314"); 
	
	while(1)
	{
		OLED_WriteCommand(0x2E);   //????
		
		OLED_WriteCommand(0x26); 
		OLED_WriteCommand(0x00); 
		OLED_WriteCommand(0x00);   
		OLED_WriteCommand(0x07);   
		OLED_WriteCommand(0x03);   
		OLED_WriteCommand(0x00); 
		OLED_WriteCommand(0xFF); 
		OLED_WriteCommand(0x2F);   

		Delay_ms(2000);   
	}
}